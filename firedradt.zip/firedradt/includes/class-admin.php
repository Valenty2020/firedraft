<?php
/**
 * Admin interface class
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Firedraft_Reports_Admin {

    private $report_templates = array();

    public function __construct() {
        $this->setup_report_templates();
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
    }

    /**
     * Setup report templates
     */
    private function setup_report_templates() {
        $this->report_templates = array(
            'website_handover_report' => array(
                'label' => __('Website Handover Report', 'firedraft-reports'),
                'description' => __('Comprehensive documentation for client website deliveries', 'firedraft-reports')
            ),
            'performance_report' => array(
                'label' => __('Performance Report', 'firedraft-reports'),
                'description' => __('Detailed site performance analysis and optimization recommendations', 'firedraft-reports')
            ),
            'site_health_report' => array(
                'label' => __('Site Health Report', 'firedraft-reports'),
                'description' => __('Overall website health assessment and maintenance status', 'firedraft-reports')
            ),
            'security_report' => array(
                'label' => __('Security Report', 'firedraft-reports'),
                'description' => __('Security assessment, vulnerabilities, and protection status', 'firedraft-reports')
            ),
            'seo_report' => array(
                'label' => __('SEO Report', 'firedraft-reports'),
                'description' => __('Search engine optimization analysis and improvement suggestions', 'firedraft-reports')
            ),
            'content_engagement_report' => array(
                'label' => __('Content Engagement Report', 'firedraft-reports'),
                'description' => __('Content performance and user engagement metrics', 'firedraft-reports')
            ),
            'executive_summary_report' => array(
                'label' => __('Executive Summary Report', 'firedraft-reports'),
                'description' => __('High-level overview for stakeholders and management', 'firedraft-reports')
            ),
            'website_improvement_proposal' => array(
                'label' => __('Website Improvement Proposal', 'firedraft-reports'),
                'description' => __('Strategic recommendations and enhancement proposals', 'firedraft-reports')
            ),
            'accessibility_audit_report' => array(
                'label' => __('Accessibility Audit Report', 'firedraft-reports'),
                'description' => __('WCAG compliance assessment and accessibility improvements', 'firedraft-reports')
            ),
            'conversion_optimization_report' => array(
                'label' => __('Conversion Optimization Report', 'firedraft-reports'),
                'description' => __('Conversion rate analysis and optimization recommendations', 'firedraft-reports')
            ),
            'form_conversion_report' => array(
                'label' => __('Form Conversion Report', 'firedraft-reports'),
                'description' => __('Form performance analysis and conversion optimization', 'firedraft-reports')
            ),
            'ecommerce_sales_report' => array(
                'label' => __('Ecommerce Sales Report', 'firedraft-reports'),
                'description' => __('Ecommerce performance and sales analytics', 'firedraft-reports')
            )
        );
    }

    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_menu_page(
            __('Firedraft', 'firedraft-reports'),
            __('Firedraft', 'firedraft-reports'),
            'manage_options',
            'firedraft-reports',
            array($this, 'admin_page'),
            FIREDRAFT_PLUGIN_URL . 'assets/images/icon.svg',
            99
        );
    }

    /**
     * Enqueue admin scripts and styles
     */
    public function enqueue_admin_scripts($hook) {
        if ($hook !== 'toplevel_page_firedraft-reports') {
            return;
        }

        // Enqueue external libraries with proper dependencies
        wp_enqueue_script('jspdf', 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js', array(), '2.5.1', true);
        wp_enqueue_script('jspdf-autotable', 'https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js', array('jspdf'), '3.5.28', true);
        wp_enqueue_script('fabric', 'https://cdnjs.cloudflare.com/ajax/libs/fabric.js/5.3.0/fabric.min.js', array(), '5.3.0', true);
        
        // Enqueue WordPress media and color picker
        wp_enqueue_media();
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');
        
        // Force TinyMCE to load
        wp_enqueue_editor();

        // Enqueue custom CSS and JS with proper dependencies
        wp_enqueue_style('firedraft-admin-css', FIREDRAFT_PLUGIN_URL . 'assets/css/admin.css', array(), FIREDRAFT_VERSION);
        wp_enqueue_script('firedraft-admin-js', FIREDRAFT_PLUGIN_URL . 'assets/js/admin.js', array('jquery', 'wp-color-picker', 'jspdf', 'fabric'), FIREDRAFT_VERSION, true);

        // Add inline script to ensure jsPDF is available
        wp_add_inline_script('firedraft-admin-js', '
            // Ensure jsPDF is available globally
            if (typeof window.jspdf !== "undefined" && window.jspdf.jsPDF) {
                window.jsPDF = window.jspdf.jsPDF;
            }
        ', 'before');

        // Localize script
        wp_localize_script('firedraft-admin-js', 'firedraftAjax', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce_generate' => wp_create_nonce('firedraft_generate_report'),
            'nonce_clear' => wp_create_nonce('firedraft_clear_report'),
            'templates' => $this->report_templates,
            'i18n' => array(
                'generating' => __('Generating...', 'firedraft-reports'),
                'generating_report' => __('Generating report from site data...', 'firedraft-reports'),
                'report_generated' => __('Report generated successfully! Reloading page...', 'firedraft-reports'),
                'error_generating' => __('Error generating report:', 'firedraft-reports'),
                'unknown_error' => __('Unknown error', 'firedraft-reports'),
                'network_error' => __('Network error:', 'firedraft-reports'),
                'clear_confirm' => __('Are you sure you want to clear all report content?', 'firedraft-reports'),
                'content_cleared' => __('Report content cleared! Reloading page...', 'firedraft-reports'),
                'generating_pdf' => __('Generating PDF document...', 'firedraft-reports'),
                'pdf_exported' => __('PDF exported successfully!', 'firedraft-reports'),
                'pdf_error' => __('Error generating PDF:', 'firedraft-reports'),
                'edit_text' => __('Edit this text', 'firedraft-reports'),
                'text_added' => __('Text added to cover page', 'firedraft-reports'),
                'image_added' => __('Image added to cover page', 'firedraft-reports'),
                'clear_cover_confirm' => __('Are you sure you want to clear the cover page design?', 'firedraft-reports'),
                'cover_cleared' => __('Cover page cleared', 'firedraft-reports'),
                'select_image' => __('Select Image for Cover Page', 'firedraft-reports'),
                'table_of_contents' => __('Table of Contents', 'firedraft-reports'),
                'firedraft_report' => __('Firedraft Report', 'firedraft-reports')
            )
        ));
    }

    /**
     * Admin page content
     */
    public function admin_page() {
        // Check capabilities
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'firedraft-reports'));
        }

        $saved_report = get_option('firedraft_report_data', '');
        $selected_template = get_option('firedraft_selected_template', 'website_handover_report');
        
        ?>
        <div class="wrap firedraft-container">
            
            <!-- Header with Firedraft branding -->
            <div class="firedraft-header">
                <span class="dashicons dashicons-media-document"></span>
                <div>
                    <h1><?php _e('Firedraft', 'firedraft-reports'); ?></h1>
                    <p><?php _e('Generate professional WordPress site reports with PDF export capabilities', 'firedraft-reports'); ?></p>
                </div>
            </div>

            <!-- Status area -->
            <div id="status-area" style="display: none;"></div>

            <!-- Report Template Selection -->
            <div class="firedraft-report-selection">
                <h3><span class="dashicons dashicons-admin-page"></span> <?php _e('Select Report Template', 'firedraft-reports'); ?></h3>
                <p><?php _e('Choose the type of report you want to generate:', 'firedraft-reports'); ?></p>
                
                <div class="firedraft-template-grid" id="template-selection">
                    <?php foreach ($this->report_templates as $key => $template) : ?>
                        <?php $is_selected = $selected_template === $key ? 'selected' : ''; ?>
                        <div class="firedraft-template-option <?php echo $is_selected; ?>" data-template="<?php echo esc_attr($key); ?>">
                            <h4><?php echo esc_html($template['label']); ?></h4>
                            <p><?php echo esc_html($template['description']); ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
                <input type="hidden" id="selected-template" name="selected_template" value="<?php echo esc_attr($selected_template); ?>">
            </div>

            <!-- Main Layout -->
            <div class="firedraft-main-layout">
                
                <!-- Left Column -->
                <div class="firedraft-left-column">
                    
                    <!-- Cover Design Section -->
                    <div class="firedraft-card">
                        <h2><span class="dashicons dashicons-format-image"></span> <?php _e('Cover Page Designer', 'firedraft-reports'); ?></h2>
                        <p><?php _e('Create a professional cover page for your report. Drag and drop elements to customize your design.', 'firedraft-reports'); ?></p>
                        
                        <div class="firedraft-canvas-container">
                            <canvas id="cover-canvas" width="600" height="800"></canvas>
                            <div class="firedraft-canvas-tools">
                                <button class="button" id="add-text">
                                    <span class="dashicons dashicons-editor-textcolor"></span> <?php _e('Add Text', 'firedraft-reports'); ?>
                                </button>
                                <input type="text" id="text-color" class="wp-color-picker" value="#000000" data-default-color="#000000" />
                                <button class="button" id="add-image">
                                    <span class="dashicons dashicons-format-image"></span> <?php _e('Add Image', 'firedraft-reports'); ?>
                                </button>
                                <label style="margin: 0 10px;"><?php _e('Background:', 'firedraft-reports'); ?></label>
                                <input type="text" id="bg-color" class="wp-color-picker" value="#ffffff" data-default-color="#ffffff" />
                                <button class="button button-secondary" id="clear-cover">
                                    <span class="dashicons dashicons-trash"></span> <?php _e('Clear', 'firedraft-reports'); ?>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Document Styling Section -->
                    <div class="firedraft-option-section">
                        <h3><span class="dashicons dashicons-admin-appearance"></span> <?php _e('Document Styling', 'firedraft-reports'); ?></h3>
                        <p><?php _e('Customize the appearance of your PDF report.', 'firedraft-reports'); ?></p>
                        
                        <div class="firedraft-form-row">
                            <div class="firedraft-form-group">
                                <label><?php _e('Heading Font Size (px)', 'firedraft-reports'); ?></label>
                                <input type="number" id="subheading-size" value="16" min="10" max="24">
                            </div>
                            <div class="firedraft-form-group">
                                <label><?php _e('Heading Font Family', 'firedraft-reports'); ?></label>
                                <select id="subheading-font">
                                    <option value="helvetica">Helvetica</option>
                                    <option value="times">Times</option>
                                    <option value="courier">Courier</option>
                                </select>
                            </div>
                        </div>
                        <div class="firedraft-form-group">
                            <label><?php _e('Heading Color', 'firedraft-reports'); ?></label>
                            <input type="text" id="subheading-color" class="wp-color-picker" value="#ff6b35" data-default-color="#ff6b35" />
                        </div>
                        
                        <div class="firedraft-form-row">
                            <div class="firedraft-form-group">
                                <label><?php _e('Body Font Size (px)', 'firedraft-reports'); ?></label>
                                <input type="number" id="body-size" value="12" min="8" max="18">
                            </div>
                            <div class="firedraft-form-group">
                                <label><?php _e('Body Font Family', 'firedraft-reports'); ?></label>
                                <select id="body-font">
                                    <option value="helvetica">Helvetica</option>
                                    <option value="times">Times</option>
                                    <option value="courier">Courier</option>
                                </select>
                            </div>
                        </div>
                        <div class="firedraft-form-group">
                            <label><?php _e('Line Spacing', 'firedraft-reports'); ?></label>
                            <select id="line-spacing">
                                <option value="0.5"><?php _e('Compact', 'firedraft-reports'); ?></option>
                                <option value="1.0" selected><?php _e('Normal', 'firedraft-reports'); ?></option>
                                <option value="1.5"><?php _e('Spacious', 'firedraft-reports'); ?></option>
                            </select>
                        </div>
                    </div>

                    <!-- Export Options Section -->
                    <div class="firedraft-option-section">
                        <h3><span class="dashicons dashicons-download"></span> <?php _e('Export Options', 'firedraft-reports'); ?></h3>
                        <p><?php _e('Configure your PDF export settings.', 'firedraft-reports'); ?></p>
                        
                        <div class="firedraft-checkbox-group">
                            <label>
                                <input type="checkbox" id="include-cover" checked> <?php _e('Include Cover Page', 'firedraft-reports'); ?>
                            </label>
                            <label>
                                <input type="checkbox" id="include-toc" checked> <?php _e('Include Table of Contents', 'firedraft-reports'); ?>
                            </label>
                            <label>
                                <input type="checkbox" id="include-page-numbers" checked> <?php _e('Include Page Numbers', 'firedraft-reports'); ?>
                            </label>
                        </div>
                        
                        <div class="firedraft-form-group">
                            <label><?php _e('Document Title', 'firedraft-reports'); ?></label>
                            <input type="text" id="document-title" value="<?php _e('Website Handover Report', 'firedraft-reports'); ?>">
                        </div>
                        
                        <div class="firedraft-form-row">
                            <div class="firedraft-form-group">
                                <label><?php _e('Author', 'firedraft-reports'); ?></label>
                                <input type="text" id="document-author" value="<?php echo esc_attr(wp_get_current_user()->display_name); ?>">
                            </div>
                            <div class="firedraft-form-group">
                                <label><?php _e('Date', 'firedraft-reports'); ?></label>
                                <input type="date" id="document-date" value="<?php echo date('Y-m-d'); ?>">
                            </div>
                        </div>
                        
                        <div class="firedraft-actions">
                            <button id="export-to-pdf" class="button button-primary firedraft-button-primary" style="font-size: 16px; padding: 12px 24px; width: 100%;">
                                <span class="dashicons dashicons-pdf"></span> <?php _e('Export to PDF', 'firedraft-reports'); ?>
                            </button>
                        </div>
                    </div>

                </div>

                <!-- Right Column: Content with TinyMCE -->
                <div class="firedraft-card">
                    <div class="firedraft-content-header">
                        <div style="flex: 1;">
                            <h2><span class="dashicons dashicons-edit"></span> <?php _e('Report Content', 'firedraft-reports'); ?></h2>
                            <p><?php _e('Generate and edit your report content. Click "Generate Report" to create content based on your site data and selected template.', 'firedraft-reports'); ?></p>
                            <div id="current-template-info" style="margin-top: 10px; padding: 10px; background: #f0f7ff; border-radius: 5px; display: inline-block;">
                                <strong><?php _e('Selected Template:', 'firedraft-reports'); ?></strong> 
                                <span id="current-template-name"><?php echo esc_html($this->report_templates[$selected_template]['label']); ?></span>
                            </div>
                        </div>
                        <div>
                            <button class="button button-primary firedraft-button-primary" id="refresh-report-button">
                                <span class="dashicons dashicons-update"></span> <?php _e('Generate Report', 'firedraft-reports'); ?>
                            </button>
                            <button class="button button-secondary" id="clear-content-button" style="display: <?php echo $saved_report ? 'inline-block' : 'none'; ?>; margin-top: 10px;">
                                <span class="dashicons dashicons-trash"></span> <?php _e('Clear Content', 'firedraft-reports'); ?>
                            </button>
                        </div>
                    </div>
                    
                    <div id="report-content-area">
                        <?php
                        // Display saved content if available
                        if (!empty($saved_report)) {
                            echo $this->render_report_content($saved_report);
                        } else {
                            echo '<div class="firedraft-status">
                                    <span class="dashicons dashicons-info"></span>
                                    <strong>' . __('No report generated yet.', 'firedraft-reports') . '</strong> ' . __('Select a template and click "Generate Report" to create your documentation.', 'firedraft-reports') . '
                                  </div>';
                        }
                        ?>
                    </div>
                </div>

            </div>
        </div>
        <?php
    }

    /**
     * Render report content with editable headers
     */
    private function render_report_content($body) {
        if (empty($body)) return '';

        $lines = explode("\n", $body);
        $current_heading = '';
        $sections = [];
        $title = '';

        foreach ($lines as $line) {
            if (preg_match('/^## (.*)/', $line, $matches)) {
                $title = trim($matches[1]);
            } elseif (preg_match('/^### (.*)/', $line, $matches)) {
                $current_heading = trim($matches[1]);
                $sections[$current_heading] = '';
            } else {
                if ($current_heading) {
                    $sections[$current_heading] .= $line . "\n";
                }
            }
        }

        $output = '';
        
        if ($title) {
            $output .= '<div class="firedraft-status success">
                          <span class="dashicons dashicons-yes"></span>
                          <strong>' . __('Report Generated:', 'firedraft-reports') . '</strong> ' . esc_html($title) . '
                        </div>';
        }

        // Render editor sections with editable headers and developer notes
        foreach ($sections as $heading => $content) {
            $clean_content = $this->strip_ai_formatting(trim($content));
            $editor_id = sanitize_title($heading);
            $clean_heading = $this->strip_ai_formatting($heading);
            
            // Check if this is a developer note section (should not be editable)
            $is_developer_note = (strpos($clean_heading, 'Required Data to Improve') !== false || 
                                 strpos($clean_heading, 'Developer Note') !== false ||
                                 strpos($clean_heading, 'Additional Data') !== false);
            
            $output .= '<div class="firedraft-editor-section">';
            
            if ($is_developer_note) {
                // Developer notes - not editable, special styling
                $output .= '<div class="firedraft-developer-note">';
                $output .= '<h4>' . esc_html($clean_heading) . '</h4>';
                $output .= '<div>' . wp_kses_post(wpautop($clean_content)) . '</div>';
                $output .= '</div>';
            } else {
                // Regular editable sections
                $output .= '<h3 class="handover-subheading" data-editor-id="' . esc_attr($editor_id) . '" contenteditable="true">' . esc_html($clean_heading) . '</h3>';

                ob_start();
                wp_editor(
                    $clean_content,
                    $editor_id,
                    [
                        'textarea_name' => $editor_id,
                        'textarea_rows' => 8,
                        'media_buttons' => false,
                        'tinymce'       => [
                            'toolbar1' => 'bold,italic,underline,bullist,numlist,alignleft,aligncenter,alignright,link,unlink,undo,redo',
                            'toolbar2' => '',
                        ],
                        'quicktags'     => true,
                        'wpautop'       => true,
                    ]
                );
                $output .= ob_get_clean();
            }
            
            $output .= '</div>';
        }

        return $output;
    }

    /**
     * Strip AI markdown-like formatting
     */
    private function strip_ai_formatting($text) {
        $patterns = [
            '/\*\*(.*?)\*\*/s',
            '/__(.*?)__/s',
            '/\*(.*?)\*/s',
            '/_(.*?)_/s',
            '/~~(.*?)~~/s',
            '/`(.*?)`/s',
        ];
        foreach ($patterns as $pattern) {
            $text = preg_replace($pattern, '$1', $text);
        }
        return trim($text);
    }

    /**
     * Get report templates
     */
    public function get_report_templates() {
        return $this->report_templates;
    }
}