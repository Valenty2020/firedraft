=== Firedraft ===
Contributors: firedraft
Donate link: https://firedraft.com/donate
Tags: reports, pdf, analysis, seo, performance, security, accessibility, forms, ecommerce
Requires at least: 5.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 3.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Generate professional WordPress site reports with PDF export capabilities including performance, security, SEO, accessibility, and forms analysis.

== Description ==

Firedraft is a powerful WordPress plugin that automatically collects and analyzes your website data to generate professional reports. Perfect for agencies, developers, and consultants who need to deliver detailed documentation to clients or stakeholders.

= Report Types =

* **Website Handover Report** - Comprehensive documentation for client deliveries
* **Performance Report** - Site performance analysis and optimization recommendations  
* **Site Health Report** - Overall website health assessment and maintenance status
* **Security Report** - Security assessment, vulnerabilities, and protection status
* **SEO Report** - Search engine optimization analysis and improvement suggestions
* **Content Engagement Report** - Content performance and user engagement metrics
* **Executive Summary Report** - High-level overview for stakeholders and management
* **Website Improvement Proposal** - Strategic recommendations and enhancement proposals
* **Accessibility Audit Report** - WCAG compliance assessment and accessibility improvements
* **Conversion Optimization Report** - Conversion rate analysis and optimization recommendations
* **Form Conversion Report** - Form performance analysis and conversion optimization
* **Ecommerce Sales Report** - Ecommerce performance and sales analytics

= Key Features =

* **Automated Data Collection** - Extracts comprehensive site data automatically
* **Visual Cover Designer** - Create custom cover pages with drag-and-drop interface  
* **PDF Export** - Professional PDF reports with custom styling and branding
* **Plugin Integration** - Detects and analyzes 100+ specialized plugins
* **Editable Content** - TinyMCE editor integration for content customization
* **Professional Styling** - Customizable fonts, colors, and formatting options

= Data Collection Categories =

**SEO Analysis**
* Meta titles and descriptions
* Sitemap detection  
* Robots.txt configuration
* SSL status
* Plugin-specific SEO data from Yoast, RankMath, All in One SEO, and more

**Performance Metrics**
* Image optimization status
* Minification detection
* Compression settings
* CDN usage analysis
* Caching configuration

**Security Assessment**
* SSL certificate status
* File permissions analysis
* Security headers validation
* Vulnerability detection
* Admin user security checks

**Forms & Conversions**
* Contact Form 7, WPForms, Gravity Forms integration
* Form submission tracking
* Newsletter signup analysis
* Conversion rate metrics

**Accessibility Compliance**
* WCAG compliance assessment
* Alt text analysis
* Keyboard navigation support
* Screen reader compatibility
* Color contrast evaluation

**E-commerce Analytics**
* WooCommerce integration
* Product catalog analysis
* Sales performance metrics
* Payment gateway configuration
* Order conversion tracking

= Plugin Compatibility =

Firedraft automatically detects and extracts data from popular WordPress plugins including:

**SEO Plugins**: Yoast SEO, RankMath, All in One SEO, SEOPress, The SEO Framework
**Performance**: WP Rocket, W3 Total Cache, Autoptimize, LiteSpeed Cache
**Security**: Wordfence, iThemes Security, Sucuri, All in One WP Security
**Forms**: Contact Form 7, WPForms, Gravity Forms, Ninja Forms, Forminator
**E-commerce**: WooCommerce, Easy Digital Downloads, BigCommerce
**Accessibility**: WP Accessibility, UserWay, accessiBe

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/firedraft/` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Navigate to 'Firedraft Reports' in your admin menu
4. Select a report template and click 'Generate Report'

== Frequently Asked Questions ==

= What types of reports can I generate? =

Firedraft offers 12 different report types including Website Handover, Performance Analysis, Security Assessment, SEO Audit, Accessibility Compliance, Form Analysis, and E-commerce Reports.

= Does the plugin work with my existing plugins? =

Yes! Firedraft automatically detects and integrates with over 100 popular WordPress plugins including Yoast SEO, WP Rocket, Wordfence, Contact Form 7, WooCommerce, and many more.

= Can I customize the reports? =

Absolutely. You can edit all report content using the built-in rich text editor, design custom cover pages, and adjust styling options including fonts, colors, and spacing.

= Are the PDFs professionally formatted? =

Yes, all exported PDFs include professional formatting with custom styling, table of contents, page numbers, and your branding elements.

= Do I need technical knowledge to use this plugin? =

No technical knowledge required. The plugin automatically collects all data and generates reports with a simple click. You can then customize the content as needed.

= Is there a limit to how many reports I can generate? =

There are no limits on report generation. Create as many reports as needed for your projects and clients.

== Screenshots ==

1. Report template selection screen
2. Visual cover page designer
3. Generated report with editable content
4. PDF export options and styling
5. Comprehensive data analysis dashboard

== Changelog ==

= 3.1.0 =
* Added new report templates (Accessibility Audit, Form Conversion)
* Enhanced forms data collection for major form plugins
* Improved accessibility compliance analysis
* Added WCAG compliance estimation
* Expanded plugin detection to 100+ plugins
* Enhanced PDF export with full content inclusion
* Developer notes exclusion from PDF exports
* Updated brand naming consistency

= 3.0.0 =
* Complete plugin rebuild with modern architecture
* Visual cover page designer with Fabric.js
* Enhanced PDF export with custom styling
* TinyMCE integration for content editing
* Comprehensive data collection across all categories
* Professional UI/UX improvements
* Mobile responsive design

== Upgrade Notice ==

= 3.1.0 =
Major update with new report templates, enhanced forms analysis, accessibility compliance features, and improved PDF export capabilities.

= 3.0.0 =
Complete plugin rebuild with visual cover designer, enhanced PDF export, and comprehensive data collection. Backup your settings before upgrading.

== License ==

This plugin is licensed under the GPLv2 or later.

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA

== Third-Party Libraries ==

* jsPDF - MIT License - https://github.com/parallax/jsPDF
* Fabric.js - MIT License - https://github.com/fabricjs/fabric.js
* WordPress Color Picker - GPL License - Part of WordPress Core
* TinyMCE - LGPL License - Part of WordPress Core